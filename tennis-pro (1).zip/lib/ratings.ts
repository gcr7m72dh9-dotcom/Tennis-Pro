import * as cheerio from "cheerio";

export type CellValue = string | number | null;

export type ColumnMeta = {
  key: string;
  label: string;
  index: number;
};

export type PlayerRow = {
  id: string;
  values: Record<string, CellValue>;
  playerName: string;
  elo: number | null;
  hElo: number | null;
  cElo: number | null;
  gElo: number | null;
};

export type Tour = "ATP" | "WTA";

export type TourPayload = {
  tour: Tour;
  sourceUrl: string;
  fallbackUsed: boolean;
  columns: ColumnMeta[];
  rows: PlayerRow[];
};

export type RatingsSnapshot = {
  scrapedAt: string;
  atp: TourPayload;
  wta: TourPayload;
};

type ParsedTable = {
  headers: string[];
  rows: string[][];
};

const ATP_URL = "https://tennisabstract.com/reports/atp_elo_ratings.html";
const WTA_URL = "https://tennisabstract.com/reports/wta_elo_ratings.html";
const SCRAPE_TIMEOUT_MS = 15000;
const SOURCE_RETRY_LIMIT = 3;
const SOURCE_RETRY_DELAY_MS = 900;

const CLOUD_FLARE_MARKERS = [
  /just a moment/i,
  /attention required/i,
  /checking your browser/i,
  /cf-browser-verification/i,
  /cloudflare/i,
];

const sanitizeKey = (value: string) =>
  value
    .toLowerCase()
    .replace(/\(.*?\)/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");

const parseCellValue = (raw: string): CellValue => {
  const text = raw.replace(/\s+/g, " ").trim();
  if (!text) {
    return null;
  }

  const numericCandidate = text.replace(/,/g, "");
  if (/^-?\d+(\.\d+)?$/.test(numericCandidate)) {
    return Number(numericCandidate);
  }

  return text;
};

const parseNumber = (value: CellValue): number | null => {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }

  if (typeof value === "string") {
    const numericCandidate = value.replace(/,/g, "").trim();
    if (/^-?\d+(\.\d+)?$/.test(numericCandidate)) {
      const parsed = Number(numericCandidate);
      return Number.isFinite(parsed) ? parsed : null;
    }
  }

  return null;
};

const normalizeHeaders = (headers: string[]): ColumnMeta[] => {
  const used = new Set<string>();

  return headers.map((header, index) => {
    const cleanLabel = header.replace(/\s+/g, " ").trim();
    const baseKey = sanitizeKey(cleanLabel || `column_${index + 1}`) || `column_${index + 1}`;
    let key = baseKey;
    let suffix = 2;

    while (used.has(key)) {
      key = `${baseKey}_${suffix}`;
      suffix += 1;
    }

    used.add(key);

    return {
      key,
      label: cleanLabel || `Column ${index + 1}`,
      index,
    };
  });
};

const parseHtmlTable = (html: string): ParsedTable | null => {
  const $ = cheerio.load(html);
  const tables = $("table").toArray();

  if (!tables.length) {
    return null;
  }

  let bestTable: ParsedTable | null = null;
  let bestScore = Number.NEGATIVE_INFINITY;

  tables.forEach((table) => {
    const allRows = $(table).find("tr").toArray();
    if (!allRows.length) {
      return;
    }

    const headers = $(allRows[0])
      .find("th, td")
      .toArray()
      .map((cell) => $(cell).text().replace(/\s+/g, " ").trim())
      .filter(Boolean);

    if (!headers.length) {
      return;
    }

    const rows = allRows
      .slice(1)
      .map((row) =>
        $(row)
          .find("th, td")
          .toArray()
          .map((cell) => $(cell).text().replace(/\s+/g, " ").trim()),
      )
      .filter((row) => row.some((cell) => cell.length > 0));

    const hasPlayerHeader = headers.some((header) => /player/i.test(header));
    const hasEloHeader = headers.some((header) => /elo/i.test(header));
    const score = (hasPlayerHeader && hasEloHeader ? 1000 : 0) + headers.length * 10 + rows.length;

    if (score > bestScore) {
      bestScore = score;
      bestTable = { headers, rows };
    }
  });

  return bestTable;
};

const stripMarkdownLinks = (value: string) =>
  value
    .replace(/\[(.*?)\]\((.*?)\)/g, "$1")
    .replace(/<br\s*\/?>(\s*)/gi, " ")
    .replace(/\\\|/g, "|")
    .trim();

const normalizeText = (value: string) =>
  value
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();

const parseMarkdownTable = (markdown: string): ParsedTable | null => {
  const lines = markdown
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.startsWith("|"));

  for (let index = 0; index < lines.length - 2; index += 1) {
    const headerLine = lines[index];
    const separatorLine = lines[index + 1];

    if (!/^\|\s*[-:|\s]+\|?$/.test(separatorLine)) {
      continue;
    }

    const headers = headerLine
      .split("|")
      .slice(1, -1)
      .map((value) => stripMarkdownLinks(value).replace(/\s+/g, " ").trim());

    if (!headers.length) {
      continue;
    }

    const rows: string[][] = [];
    for (let rowIndex = index + 2; rowIndex < lines.length; rowIndex += 1) {
      const rowLine = lines[rowIndex];
      if (!rowLine.startsWith("|")) {
        break;
      }

      const cells = rowLine
        .split("|")
        .slice(1, -1)
        .map((value) => stripMarkdownLinks(value).replace(/\s+/g, " ").trim());

      if (cells.every((cell) => !cell)) {
        continue;
      }

      rows.push(cells);
    }

    if (rows.length) {
      return { headers, rows };
    }
  }

  return null;
};

const parseTabSeparatedTable = (content: string): ParsedTable | null => {
  const lines = content.split("\n").map((line) => line.replace(/\r/g, ""));

  const headerIndex = lines.findIndex(
    (line) => line.includes("\t") && /player/i.test(line) && /elo/i.test(line),
  );

  if (headerIndex === -1) {
    return null;
  }

  const headers = lines[headerIndex].split("\t").map((cell) => normalizeText(cell));
  if (!headers.length) {
    return null;
  }

  const rows: string[][] = [];

  for (let lineIndex = headerIndex + 1; lineIndex < lines.length; lineIndex += 1) {
    const line = lines[lineIndex];
    if (!line.includes("\t")) {
      if (rows.length) {
        break;
      }
      continue;
    }

    const cells = line.split("\t").map((cell) => normalizeText(cell));
    if (!cells.some((cell) => cell.length > 0)) {
      if (rows.length) {
        break;
      }
      continue;
    }

    if (!/^\d+$/.test(cells[0])) {
      if (rows.length) {
        break;
      }
      continue;
    }

    rows.push(cells);
  }

  if (!rows.length) {
    return null;
  }

  return {
    headers,
    rows,
  };
};

const parseFallbackTable = (content: string): ParsedTable | null =>
  parseMarkdownTable(content) ?? parseTabSeparatedTable(content);

const waitForDelay = async (delayMs: number) =>
  new Promise<void>((resolve) => {
    setTimeout(resolve, delayMs);
  });

const extractErrorMessage = (error: unknown) => {
  if (error instanceof Error) {
    return error.message;
  }

  return String(error);
};

const looksLikeCloudflareBlock = (content: string) =>
  CLOUD_FLARE_MARKERS.some((marker) => marker.test(content));

const fetchWithTimeout = async (input: string, init: RequestInit = {}) => {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), SCRAPE_TIMEOUT_MS);

  try {
    return await fetch(input, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
};

const fetchRawPage = async (url: string) => {
  let directFailureReason = "Unable to load table directly";

  try {
    const directResponse = await fetchWithTimeout(url, {
      headers: {
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
        accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "accept-language": "en-US,en;q=0.9",
        pragma: "no-cache",
        "cache-control": "no-cache",
      },
      cache: "no-store",
    });

    if (!directResponse.ok) {
      directFailureReason = `Source returned HTTP ${directResponse.status}`;
    } else {
      const directHtml = await directResponse.text();
      if (looksLikeCloudflareBlock(directHtml)) {
        directFailureReason = "Source blocked automated requests with an anti-bot challenge";
      } else if (parseHtmlTable(directHtml)) {
        return { mode: "direct" as const, content: directHtml };
      } else {
        directFailureReason = "Source response did not contain a recognizable ratings table";
      }
    }
  } catch (error) {
    directFailureReason = `Direct request failed: ${extractErrorMessage(error)}`;
  }

  const parsedUrl = new URL(url);
  const fallbackUrl = `https://r.jina.ai/http://${parsedUrl.host}${parsedUrl.pathname}${parsedUrl.search}`;
  const fallbackResponse = await fetchWithTimeout(fallbackUrl, { cache: "no-store" });

  if (!fallbackResponse.ok) {
    throw new Error(
      `${directFailureReason}. Fallback mirror also failed with HTTP ${fallbackResponse.status}.`,
    );
  }

  const markdown = await fallbackResponse.text();
  if (!parseFallbackTable(markdown)) {
    throw new Error(
      `${directFailureReason}. Fallback response did not contain a parseable ratings table.`,
    );
  }

  return { mode: "fallback" as const, content: markdown };
};

const buildTourPayload = async (tour: Tour, sourceUrl: string): Promise<TourPayload> => {
  let latestError = "Unknown scraping error";

  for (let attempt = 1; attempt <= SOURCE_RETRY_LIMIT; attempt += 1) {
    try {
      const rawPage = await fetchRawPage(sourceUrl);
      const parsed =
        rawPage.mode === "direct" ? parseHtmlTable(rawPage.content) : parseFallbackTable(rawPage.content);

      if (!parsed) {
        throw new Error(`Unable to parse ${tour} ratings table`);
      }

      const columns = normalizeHeaders(parsed.headers);

      const playerColumn = columns.find((column) => /player/i.test(column.label));
      const eloColumn = columns.find((column) => /^elo$/i.test(column.label.trim()));
      const hEloColumn = columns.find(
        (column) => /^h\s*elo$/i.test(column.label.trim()) || /hard/i.test(column.label),
      );
      const cEloColumn = columns.find(
        (column) => /^c\s*elo$/i.test(column.label.trim()) || /clay/i.test(column.label),
      );
      const gEloColumn = columns.find(
        (column) => /^g\s*elo$/i.test(column.label.trim()) || /grass/i.test(column.label),
      );

      const rows: PlayerRow[] = parsed.rows.map((rawRow, rowIndex) => {
        const values: Record<string, CellValue> = {};

        columns.forEach((column, columnIndex) => {
          const rawCell = rawRow[columnIndex] ?? "";
          values[column.key] = parseCellValue(rawCell);
        });

        const playerNameCell = playerColumn
          ? values[playerColumn.key]
          : values[columns[1]?.key ?? columns[0].key];
        const playerName = String(playerNameCell ?? `Player ${rowIndex + 1}`).trim();

        return {
          id: `${tour}-${rowIndex + 1}-${playerName.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
          values,
          playerName,
          elo: eloColumn ? parseNumber(values[eloColumn.key]) : null,
          hElo: hEloColumn ? parseNumber(values[hEloColumn.key]) : null,
          cElo: cEloColumn ? parseNumber(values[cEloColumn.key]) : null,
          gElo: gEloColumn ? parseNumber(values[gEloColumn.key]) : null,
        };
      });

      return {
        tour,
        sourceUrl,
        fallbackUsed: rawPage.mode === "fallback",
        columns,
        rows,
      };
    } catch (error) {
      latestError = extractErrorMessage(error);
      if (attempt < SOURCE_RETRY_LIMIT) {
        await waitForDelay(SOURCE_RETRY_DELAY_MS * attempt);
      }
    }
  }

  throw new Error(`Unable to load ${tour} ratings after ${SOURCE_RETRY_LIMIT} attempts. ${latestError}`);
};

export const fetchRatingsSnapshot = async (): Promise<RatingsSnapshot> => {
  const [atp, wta] = await Promise.all([
    buildTourPayload("ATP", ATP_URL),
    buildTourPayload("WTA", WTA_URL),
  ]);

  return {
    scrapedAt: new Date().toISOString(),
    atp,
    wta,
  };
};
