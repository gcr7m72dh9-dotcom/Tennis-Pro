"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CalendarDays, Download, RefreshCw, Search, Swords, Trash2, Trophy, TrendingUp } from "lucide-react";
import { toPng } from "html-to-image";
import { Button } from "@/components/ui/button";
import type { CellValue, PlayerRow, RatingsSnapshot, Tour, TourPayload } from "@/lib/ratings";

type ActiveTab = Tour | "MATCHUP";
type Surface = "overall" | "hard" | "clay" | "grass";
type SortDirection = "asc" | "desc";

type RatingsResponse = RatingsSnapshot;

type PlayerChoice = PlayerRow & { tour: Tour };

type TableControls = {
  search: string;
  sortKey: string;
  sortDirection: SortDirection;
};

type DaySheetEntry = {
  id: string;
  player1: string;
  player2: string;
  surface: Surface;
  player1Prob: number;
  player2Prob: number;
  player1AmericanOdds: string;
  player2AmericanOdds: string;
  player1DecimalOdds: string;
  player2DecimalOdds: string;
  player1FractionalOdds: string;
  player2FractionalOdds: string;
  timestamp: string;
};

const SURFACES: { key: Surface; label: string }[] = [
  { key: "overall", label: "Overall" },
  { key: "hard", label: "Hard" },
  { key: "clay", label: "Clay" },
  { key: "grass", label: "Grass" },
];

const API_RETRY_LIMIT = 3;
const API_TIMEOUT_MS = 20000;
const API_RETRY_DELAY_MS = 750;

function TennisProBrandMark() {
  return (
    <div className="flex items-center gap-4">
      <div className="relative h-[78px] w-[78px] shrink-0">
        <div className="absolute inset-0 rounded-full bg-primary/20 blur-xl" />
        <svg
          viewBox="0 0 84 84"
          className="relative h-full w-full"
          role="img"
          aria-label="Tennis Pro logo"
        >
          <circle cx="42" cy="42" r="38" fill="var(--primary)" fillOpacity="0.14" />
          <circle cx="42" cy="42" r="32" fill="none" stroke="var(--primary)" strokeWidth="2.5" />
          <path
            d="M23 17.5c10.5 7.2 16.5 15.6 16.5 24.5S33.5 59.3 23 66.5"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M61 17.5C50.5 24.7 44.5 33.1 44.5 42S50.5 59.3 61 66.5"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M24 53.5l8.5-7.8 8 6.2 12.6-15.4"
            fill="none"
            stroke="var(--accent)"
            strokeWidth="3.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="24" cy="53.5" r="2.8" fill="var(--accent)" />
          <circle cx="40.5" cy="52" r="2.8" fill="var(--accent)" />
          <circle cx="53" cy="36.5" r="2.8" fill="var(--accent)" />
        </svg>
      </div>
      <div>
        <h1 className="font-display text-4xl font-extrabold uppercase leading-none tracking-[0.14em] text-white md:text-5xl">
          Tennis Pro
        </h1>
        <p className="mt-2 text-xs font-semibold uppercase tracking-[0.22em] text-emerald-100/75 md:text-sm">
          Elite Match Intelligence
        </p>
      </div>
    </div>
  );
}

function TennisProSheetMark() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-full border border-primary/45 bg-emerald-950/45">
        <div className="absolute inset-0 bg-primary/20 blur-lg" />
        <svg viewBox="0 0 84 84" className="relative h-full w-full" role="img" aria-label="Tennis Pro sheet logo">
          <circle cx="42" cy="42" r="38" fill="var(--primary)" fillOpacity="0.14" />
          <circle cx="42" cy="42" r="31" fill="none" stroke="var(--primary)" strokeWidth="2.6" />
          <path
            d="M23 17.5c10.5 7.2 16.5 15.6 16.5 24.5S33.5 59.3 23 66.5"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M61 17.5C50.5 24.7 44.5 33.1 44.5 42S50.5 59.3 61 66.5"
            fill="none"
            stroke="var(--primary)"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M24 53.5l8.5-7.8 8 6.2 12.6-15.4"
            fill="none"
            stroke="var(--accent)"
            strokeWidth="3.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div>
        <p className="font-display text-lg font-bold uppercase tracking-[0.1em] text-white">Tennis Pro</p>
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-100/70">Day Sheet</p>
      </div>
    </div>
  );
}

const formatCell = (value: CellValue) => {
  if (value === null || value === undefined || value === "") {
    return "—";
  }

  if (typeof value === "number") {
    return Number.isInteger(value)
      ? value.toLocaleString("en-US")
      : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
  }

  return value;
};

const formatElo = (value: number | null) => {
  if (value === null || Number.isNaN(value)) {
    return "—";
  }

  return value.toLocaleString("en-US", { maximumFractionDigits: 1 });
};

const compareValues = (a: CellValue, b: CellValue) => {
  if (a === null && b === null) {
    return 0;
  }

  if (a === null) {
    return 1;
  }

  if (b === null) {
    return -1;
  }

  if (typeof a === "number" && typeof b === "number") {
    return a - b;
  }

  return String(a).localeCompare(String(b), undefined, { sensitivity: "base" });
};

const toAmericanOdds = (probability: number) => {
  if (probability <= 0 || probability >= 1) {
    return "—";
  }

  if (probability >= 0.5) {
    const value = Math.round((probability / (1 - probability)) * 100);
    return `-${value}`;
  }

  const value = Math.round(((1 - probability) / probability) * 100);
  return `+${value}`;
};

const toDecimalOdds = (probability: number) => {
  if (probability <= 0) {
    return "—";
  }

  return (1 / probability).toFixed(2);
};

const gcd = (a: number, b: number): number => {
  const absA = Math.abs(a);
  const absB = Math.abs(b);
  if (!absB) {
    return absA;
  }

  return gcd(absB, absA % absB);
};

const toFractionalOdds = (probability: number) => {
  if (probability <= 0 || probability >= 1) {
    return "—";
  }

  const fractionalValue = 1 / probability - 1;
  const denominator = 1000;
  const numerator = Math.round(fractionalValue * denominator);

  if (numerator <= 0) {
    return "0/1";
  }

  const divider = gcd(numerator, denominator);
  return `${numerator / divider}/${denominator / divider}`;
};

const getSurfaceLabel = (surface: Surface) => SURFACES.find((option) => option.key === surface)?.label ?? "Overall";

const formatDaySheetDate = (value: string) =>
  new Date(value).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

const toPercent = (value: number) => `${(value * 100).toFixed(1)}%`;

const getDaySheetFileName = () => {
  const now = new Date();
  const date = now.toLocaleDateString("en-CA");
  return `tennis-pro-day-sheet-${date}.png`;
};

const waitForDelay = async (delayMs: number) =>
  new Promise<void>((resolve) => {
    window.setTimeout(resolve, delayMs);
  });

const isRatingsResponse = (payload: unknown): payload is RatingsResponse => {
  if (!payload || typeof payload !== "object") {
    return false;
  }

  const candidate = payload as Partial<RatingsResponse>;
  return Boolean(candidate.atp && candidate.wta && candidate.scrapedAt);
};

const getRatingsErrorMessage = (error: unknown) => {
  if (error instanceof DOMException && error.name === "AbortError") {
    return "Request timed out while loading ratings data.";
  }

  return error instanceof Error ? error.message : "Unexpected error while loading ratings";
};

const parseApiErrorMessage = async (response: Response) => {
  const rawBody = await response.text();
  try {
    const payload = JSON.parse(rawBody) as { error?: string; hint?: string };
    const combined = [payload.error, payload.hint].filter(Boolean).join(" ");
    return combined || `Ratings request failed with HTTP ${response.status}`;
  } catch {
    return rawBody.trim() || `Ratings request failed with HTTP ${response.status}`;
  }
};

const fetchRatingsWithRetry = async (): Promise<RatingsResponse> => {
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= API_RETRY_LIMIT; attempt += 1) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), API_TIMEOUT_MS);

    try {
      const response = await fetch("/api/scrape-ratings", {
        cache: "no-store",
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(await parseApiErrorMessage(response));
      }

      const payload = (await response.json()) as unknown;
      if (!isRatingsResponse(payload)) {
        throw new Error("Ratings API returned an invalid payload shape");
      }

      return payload;
    } catch (error) {
      lastError = new Error(getRatingsErrorMessage(error));
      if (attempt < API_RETRY_LIMIT) {
        await waitForDelay(API_RETRY_DELAY_MS * attempt);
      }
    } finally {
      window.clearTimeout(timeout);
    }
  }

  throw lastError ?? new Error("Unable to load ratings data");
};

const extractSurfaceRating = (player: PlayerChoice, surface: Surface) => {
  if (surface === "overall") {
    return { value: player.elo, fallback: false };
  }

  const surfaceMap: Record<Exclude<Surface, "overall">, number | null> = {
    hard: player.hElo,
    clay: player.cElo,
    grass: player.gElo,
  };

  const value = surfaceMap[surface];
  if (value === null || value === undefined) {
    return { value: player.elo, fallback: true };
  }

  return { value, fallback: false };
};

type RatingsTableTabProps = {
  title: string;
  subtitle: string;
  tourData: TourPayload | null;
  controls: TableControls;
  onControlsChange: (controls: TableControls) => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  isInitialLoading: boolean;
  error: string | null;
};

function RatingsTableTab({
  title,
  subtitle,
  tourData,
  controls,
  onControlsChange,
  onRefresh,
  isRefreshing,
  isInitialLoading,
  error,
}: RatingsTableTabProps) {
  const columnCount = tourData?.columns.length ?? 16;

  const visibleRows = useMemo(() => {
    if (!tourData) {
      return [];
    }

    const query = controls.search.trim().toLowerCase();

    const filtered = query
      ? tourData.rows.filter((row) => row.playerName.toLowerCase().includes(query))
      : tourData.rows;

    if (!controls.sortKey) {
      return filtered;
    }

    return [...filtered].sort((rowA, rowB) => {
      const result = compareValues(
        rowA.values[controls.sortKey] ?? null,
        rowB.values[controls.sortKey] ?? null,
      );

      return controls.sortDirection === "asc" ? result : -result;
    });
  }, [tourData, controls.search, controls.sortDirection, controls.sortKey]);

  const handleSortToggle = (sortKey: string) => {
    if (controls.sortKey !== sortKey) {
      onControlsChange({
        ...controls,
        sortKey,
        sortDirection: "desc",
      });
      return;
    }

    onControlsChange({
      ...controls,
      sortDirection: controls.sortDirection === "desc" ? "asc" : "desc",
    });
  };

  return (
    <section className="rounded-3xl border border-primary/35 bg-black/35 p-5 shadow-[0_20px_80px_-35px_rgba(46,227,145,0.6)] backdrop-blur-xl">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="space-y-1">
          <h2 className="font-display text-3xl font-bold uppercase tracking-wide text-white">{title}</h2>
          <p className="text-sm text-emerald-100/70">{subtitle}</p>
        </div>

        <Button
          onClick={onRefresh}
          className="h-11 bg-primary/90 px-5 text-sm font-semibold text-primary-foreground hover:bg-primary"
        >
          <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
          {isRefreshing ? "Refreshing Data" : "Refresh Data"}
        </Button>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <label className="relative w-full max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-100/50" />
          <input
            value={controls.search}
            onChange={(event) => onControlsChange({ ...controls, search: event.target.value })}
            placeholder="Search player..."
            className="h-11 w-full rounded-xl border border-emerald-300/30 bg-emerald-950/35 pl-10 pr-3 text-sm text-white outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
          />
        </label>

        <div className="rounded-xl border border-emerald-300/25 bg-emerald-950/40 px-3 py-2 text-xs text-emerald-100/80">
          {visibleRows.length.toLocaleString("en-US")} players shown
        </div>

        {tourData?.fallbackUsed ? (
          <div className="rounded-xl border border-amber-300/40 bg-amber-300/10 px-3 py-2 text-xs text-amber-100">
            Cloudflare fallback mode active
          </div>
        ) : null}
      </div>

      {error ? (
        <div className="mt-5 rounded-xl border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-100">
          <p className="font-semibold">Unable to refresh ratings right now.</p>
          <p className="mt-1 text-red-100/90">{error}</p>
          <Button
            onClick={onRefresh}
            variant="outline"
            className="mt-3 border-red-300/50 bg-transparent text-red-100 hover:bg-red-500/20"
          >
            Retry
          </Button>
        </div>
      ) : null}

      <div className="mt-5 overflow-hidden rounded-2xl border border-emerald-300/30">
        <div className="max-h-[560px] overflow-auto">
          <table className="min-w-full border-collapse text-sm">
            <thead className="sticky top-0 z-10 bg-emerald-900/75 backdrop-blur">
              <tr>
                {(tourData?.columns ?? []).map((column) => {
                  const isActiveSort = controls.sortKey === column.key;
                  const sortIndicator = isActiveSort
                    ? controls.sortDirection === "desc"
                      ? "↓"
                      : "↑"
                    : "↕";

                  return (
                    <th key={column.key} className="border-b border-emerald-300/30 px-3 py-2 text-left">
                      <button
                        className="flex items-center gap-2 font-semibold text-emerald-50/95 transition hover:text-primary"
                        onClick={() => handleSortToggle(column.key)}
                      >
                        <span>{column.label}</span>
                        <span className="text-xs opacity-70">{sortIndicator}</span>
                      </button>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {isInitialLoading && !tourData
                ? Array.from({ length: 16 }).map((_, index) => (
                    <tr key={`skeleton-${index}`} className={index % 2 === 0 ? "bg-black/20" : "bg-emerald-950/20"}>
                      <td colSpan={columnCount} className="px-3 py-3">
                        <div className="h-4 w-full animate-pulse rounded bg-emerald-300/20" />
                      </td>
                    </tr>
                  ))
                : visibleRows.map((row, index) => (
                    <tr
                      key={row.id}
                      className={`transition hover:bg-primary/15 ${
                        index % 2 === 0 ? "bg-black/20" : "bg-emerald-950/20"
                      }`}
                    >
                      {(tourData?.columns ?? []).map((column) => (
                        <td key={`${row.id}-${column.key}`} className="border-b border-emerald-300/10 px-3 py-2 text-emerald-50/90">
                          {formatCell(row.values[column.key] ?? null)}
                        </td>
                      ))}
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

type PlayerComboboxProps = {
  label: string;
  placeholder: string;
  selectedPlayer: PlayerChoice | null;
  options: PlayerChoice[];
  excludeId?: string | null;
  onSelect: (playerId: string | null) => void;
};

function PlayerCombobox({
  label,
  placeholder,
  selectedPlayer,
  options,
  excludeId,
  onSelect,
}: PlayerComboboxProps) {
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!selectedPlayer) {
      setQuery("");
      return;
    }

    setQuery(`${selectedPlayer.playerName} (${selectedPlayer.tour})`);
  }, [selectedPlayer]);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();

    return options
      .filter((option) => option.id !== excludeId)
      .filter((option) => {
        if (!normalized) {
          return true;
        }

        return `${option.playerName} ${option.tour}`.toLowerCase().includes(normalized);
      })
      .slice(0, 10);
  }, [excludeId, options, query]);

  return (
    <div className="relative w-full">
      <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100/65">{label}</p>
      <label className="relative block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-100/50" />
        <input
          value={query}
          onFocus={() => setIsOpen(true)}
          onBlur={() => window.setTimeout(() => setIsOpen(false), 120)}
          onChange={(event) => {
            setQuery(event.target.value);
            setIsOpen(true);
            onSelect(null);
          }}
          placeholder={placeholder}
          className="h-12 w-full rounded-xl border border-emerald-300/35 bg-emerald-950/35 pl-10 pr-12 text-sm text-white outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/35"
        />
      </label>

      {selectedPlayer ? (
        <button
          onMouseDown={(event) => {
            event.preventDefault();
            onSelect(null);
            setQuery("");
          }}
          className="absolute right-2 top-[31px] rounded-md border border-emerald-200/35 px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-emerald-100/85 transition hover:bg-emerald-300/20"
        >
          Clear
        </button>
      ) : null}

      {isOpen ? (
        <div className="absolute z-30 mt-2 max-h-64 w-full overflow-auto rounded-xl border border-emerald-300/35 bg-emerald-950/95 p-1 shadow-2xl shadow-black/40 backdrop-blur">
          {filtered.length ? (
            filtered.map((option) => (
              <button
                key={option.id}
                onMouseDown={(event) => {
                  event.preventDefault();
                  onSelect(option.id);
                  setQuery(`${option.playerName} (${option.tour})`);
                  setIsOpen(false);
                }}
                className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm text-emerald-50/90 transition hover:bg-primary/20"
              >
                <span>{option.playerName}</span>
                <span
                  className={`rounded px-2 py-0.5 text-[10px] font-semibold tracking-wider ${
                    option.tour === "ATP"
                      ? "bg-sky-400/20 text-sky-100"
                      : "bg-pink-400/20 text-pink-100"
                  }`}
                >
                  {option.tour}
                </span>
              </button>
            ))
          ) : (
            <p className="px-3 py-2 text-sm text-emerald-100/70">No matching players.</p>
          )}
        </div>
      ) : null}
    </div>
  );
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("ATP");
  const [data, setData] = useState<RatingsResponse | null>(null);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [refreshingTour, setRefreshingTour] = useState<Tour | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [controls, setControls] = useState<Record<Tour, TableControls>>({
    ATP: { search: "", sortKey: "", sortDirection: "desc" },
    WTA: { search: "", sortKey: "", sortDirection: "desc" },
  });

  const [surface, setSurface] = useState<Surface>("overall");
  const [playerAId, setPlayerAId] = useState<string | null>(null);
  const [playerBId, setPlayerBId] = useState<string | null>(null);
  const [daySheet, setDaySheet] = useState<DaySheetEntry[]>([]);
  const [isDownloadingDaySheet, setIsDownloadingDaySheet] = useState(false);
  const daySheetCaptureRef = useRef<HTMLDivElement | null>(null);

  const fetchRatings = useCallback(async (requestedTour?: Tour) => {
    if (requestedTour) {
      setRefreshingTour(requestedTour);
    }

    if (!requestedTour) {
      setIsInitialLoading(true);
    }

    try {
      setError(null);
      const payload = await fetchRatingsWithRetry();
      setData(payload);

      setControls((previous) => ({
        ATP: {
          ...previous.ATP,
          sortKey: previous.ATP.sortKey || payload.atp.columns[0]?.key || "",
        },
        WTA: {
          ...previous.WTA,
          sortKey: previous.WTA.sortKey || payload.wta.columns[0]?.key || "",
        },
      }));
    } catch (fetchError) {
      setError(getRatingsErrorMessage(fetchError));
    } finally {
      setIsInitialLoading(false);
      setRefreshingTour(null);
    }
  }, []);

  useEffect(() => {
    void fetchRatings();
  }, [fetchRatings]);

  const atpData = data?.atp ?? null;
  const wtaData = data?.wta ?? null;

  const playerPool = useMemo<PlayerChoice[]>(() => {
    if (!atpData || !wtaData) {
      return [];
    }

    return [...atpData.rows.map((row) => ({ ...row, tour: "ATP" as const })), ...wtaData.rows.map((row) => ({ ...row, tour: "WTA" as const }))]
      .sort((a, b) => a.playerName.localeCompare(b.playerName));
  }, [atpData, wtaData]);

  const playerA = useMemo(
    () => playerPool.find((player) => player.id === playerAId) ?? null,
    [playerPool, playerAId],
  );
  const playerB = useMemo(
    () => playerPool.find((player) => player.id === playerBId) ?? null,
    [playerPool, playerBId],
  );

  useEffect(() => {
    if (playerAId && !playerPool.some((player) => player.id === playerAId)) {
      setPlayerAId(null);
    }

    if (playerBId && !playerPool.some((player) => player.id === playerBId)) {
      setPlayerBId(null);
    }
  }, [playerAId, playerBId, playerPool]);

  const matchup = useMemo(() => {
    if (!playerA || !playerB) {
      return null;
    }

    const ratingA = extractSurfaceRating(playerA, surface);
    const ratingB = extractSurfaceRating(playerB, surface);

    if (ratingA.value === null || ratingB.value === null) {
      return {
        ratingA,
        ratingB,
        probabilityA: null,
      };
    }

    const probabilityA = 1 / (1 + 10 ** ((ratingB.value - ratingA.value) / 400));

    return {
      ratingA,
      ratingB,
      probabilityA,
    };
  }, [playerA, playerB, surface]);

  const probabilityA = matchup?.probabilityA ?? null;
  const probabilityB = probabilityA === null ? null : 1 - probabilityA;

  const addCurrentMatchToDaySheet = () => {
    if (!playerA || !playerB || probabilityA === null || probabilityB === null) {
      return;
    }

    const entry: DaySheetEntry = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      player1: playerA.playerName,
      player2: playerB.playerName,
      surface,
      player1Prob: probabilityA,
      player2Prob: probabilityB,
      player1AmericanOdds: toAmericanOdds(probabilityA),
      player2AmericanOdds: toAmericanOdds(probabilityB),
      player1DecimalOdds: toDecimalOdds(probabilityA),
      player2DecimalOdds: toDecimalOdds(probabilityB),
      player1FractionalOdds: toFractionalOdds(probabilityA),
      player2FractionalOdds: toFractionalOdds(probabilityB),
      timestamp: new Date().toISOString(),
    };

    setDaySheet((previous) => [entry, ...previous]);
  };

  const removeFromDaySheet = (entryId: string) => {
    setDaySheet((previous) => previous.filter((entry) => entry.id !== entryId));
  };

  const clearDaySheet = () => {
    setDaySheet([]);
  };

  const downloadDaySheetAsImage = async () => {
    if (!daySheetCaptureRef.current || !daySheet.length) {
      return;
    }

    try {
      setIsDownloadingDaySheet(true);
      const fileName = getDaySheetFileName();
      const dataUrl = await toPng(daySheetCaptureRef.current, {
        cacheBust: true,
        pixelRatio: 2,
        backgroundColor: "#081810",
      });

      try {
        const share = (navigator as Navigator & { share?: (data: { title?: string; files?: File[] }) => Promise<void> }).share;
        if (share && typeof File !== "undefined") {
          const imageBlob = await (await fetch(dataUrl)).blob();
          const imageFile = new File([imageBlob], fileName, { type: "image/png" });
          await share({
            title: "Tennis Pro Day Sheet",
            files: [imageFile],
          });
          return;
        }
      } catch {
      }

      const link = document.createElement("a");
      link.download = fileName;
      link.href = dataUrl;
      link.click();
    } finally {
      setIsDownloadingDaySheet(false);
    }
  };

  return (
    <main className="mx-auto min-h-screen w-full max-w-[1500px] px-4 pb-10 pt-8 md:px-8">
      <header className="relative overflow-hidden rounded-3xl border border-primary/35 bg-black/30 p-6 shadow-[0_35px_120px_-45px_rgba(88,248,166,0.85)] backdrop-blur-xl">
        <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -bottom-20 left-0 h-48 w-48 rounded-full bg-accent/20 blur-3xl" />

        <div className="relative flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="mb-2 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/15 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-emerald-50/90">
              <Trophy className="h-3.5 w-3.5" />
              Live Elo Command Center
            </p>
            <TennisProBrandMark />
            <p className="mt-2 max-w-2xl text-sm text-emerald-100/80 md:text-base">
              ATP + WTA Elo ratings with a surface-aware matchup predictor and live betting odds conversion.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-3">
            <div className="rounded-2xl border border-emerald-300/30 bg-emerald-950/25 px-4 py-3 text-right text-xs text-emerald-50/80">
              <p className="uppercase tracking-[0.16em] text-emerald-100/65">Last refresh</p>
              <p className="mt-1 font-semibold text-emerald-50">
                {data?.scrapedAt
                  ? new Date(data.scrapedAt).toLocaleString("en-US", {
                      dateStyle: "medium",
                      timeStyle: "short",
                    })
                  : "Waiting for live feed"}
              </p>
            </div>
          </div>
        </div>
      </header>

      <section className="mt-7">
        <div className="grid grid-cols-1 gap-2 rounded-2xl border border-emerald-300/30 bg-emerald-950/35 p-2 md:grid-cols-3">
          {[
            { key: "ATP" as const, label: "Men’s Tennis (ATP)" },
            { key: "WTA" as const, label: "Women’s Tennis (WTA)" },
            { key: "MATCHUP" as const, label: "Head to Head Matchup" },
          ].map((tab) => {
            const active = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`h-12 rounded-xl px-4 text-sm font-semibold transition ${
                  active
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/35"
                    : "bg-transparent text-emerald-100/80 hover:bg-emerald-500/15"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </section>

      <section className="mt-6 space-y-6">
        {activeTab === "ATP" ? (
          <RatingsTableTab
            title="ATP Elo Ratings"
            subtitle="Complete men’s table from Tennis Abstract with sortable columns and live refresh."
            tourData={atpData}
            controls={controls.ATP}
            onControlsChange={(next) => setControls((previous) => ({ ...previous, ATP: next }))}
            onRefresh={() => void fetchRatings("ATP")}
            isRefreshing={refreshingTour === "ATP"}
            isInitialLoading={isInitialLoading}
            error={error}
          />
        ) : null}

        {activeTab === "WTA" ? (
          <RatingsTableTab
            title="WTA Elo Ratings"
            subtitle="Complete women’s table from Tennis Abstract with sortable columns and live refresh."
            tourData={wtaData}
            controls={controls.WTA}
            onControlsChange={(next) => setControls((previous) => ({ ...previous, WTA: next }))}
            onRefresh={() => void fetchRatings("WTA")}
            isRefreshing={refreshingTour === "WTA"}
            isInitialLoading={isInitialLoading}
            error={error}
          />
        ) : null}

        {activeTab === "MATCHUP" ? (
          <section className="rounded-3xl border border-primary/35 bg-black/35 p-5 shadow-[0_25px_100px_-45px_rgba(88,248,166,0.9)] backdrop-blur-xl md:p-7">
            <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="mb-2 inline-flex items-center gap-2 rounded-full border border-primary/35 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100/80">
                  <Swords className="h-3.5 w-3.5" />
                  Matchup Engine
                </p>
                <h2 className="font-display text-3xl font-bold uppercase tracking-wide text-white md:text-4xl">
                  Head to Head Predictor
                </h2>
              </div>

              <Button
                onClick={() => void fetchRatings("ATP")}
                variant="outline"
                className="border-emerald-200/45 bg-emerald-900/15 text-emerald-50 hover:bg-emerald-700/25"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh Player Pool
              </Button>
            </div>

            {error ? (
              <div className="mb-5 rounded-xl border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-100">
                <p className="font-semibold">Unable to refresh ratings right now.</p>
                <p className="mt-1 text-red-100/90">{error}</p>
                <Button
                  onClick={() => void fetchRatings("ATP")}
                  variant="outline"
                  className="mt-3 border-red-300/50 bg-transparent text-red-100 hover:bg-red-500/20"
                >
                  Retry
                </Button>
              </div>
            ) : null}

            <div className="grid gap-4 lg:grid-cols-[1fr_auto_1fr] lg:items-end">
              <PlayerCombobox
                label="Player A"
                placeholder="Search ATP or WTA player"
                selectedPlayer={playerA}
                options={playerPool}
                excludeId={playerBId}
                onSelect={setPlayerAId}
              />

              <div className="mx-auto mb-3 hidden rounded-full border border-emerald-300/35 bg-emerald-900/20 px-5 py-2 font-display text-xl font-bold uppercase tracking-[0.2em] text-emerald-100 lg:block">
                VS
              </div>

              <PlayerCombobox
                label="Player B"
                placeholder="Search ATP or WTA player"
                selectedPlayer={playerB}
                options={playerPool}
                excludeId={playerAId}
                onSelect={setPlayerBId}
              />
            </div>

            <div className="mt-5 rounded-2xl border border-emerald-300/30 bg-emerald-950/25 p-4">
              <p className="mb-3 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100/65">Court Surface</p>
              <div className="grid gap-2 sm:grid-cols-4">
                {SURFACES.map((option) => {
                  const active = surface === option.key;
                  return (
                    <button
                      key={option.key}
                      onClick={() => setSurface(option.key)}
                      className={`h-11 rounded-xl border text-sm font-semibold transition ${
                        active
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-emerald-300/30 bg-emerald-900/15 text-emerald-100/85 hover:bg-emerald-700/20"
                      }`}
                    >
                      {option.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {!playerA || !playerB ? (
              <div className="mt-6 rounded-2xl border border-dashed border-emerald-300/35 bg-emerald-950/15 p-8 text-center text-emerald-100/75">
                Pick two players to generate the probability model and betting odds.
              </div>
            ) : matchup && probabilityA !== null && probabilityB !== null ? (
              <div className="mt-6 overflow-hidden rounded-2xl border border-primary/35 bg-gradient-to-r from-emerald-950/45 via-black/40 to-emerald-950/45 p-5 shadow-inner shadow-emerald-300/10 md:p-6">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100/70">
                    Matchup ready for {getSurfaceLabel(surface)} court
                  </p>
                  <Button
                    onClick={addCurrentMatchToDaySheet}
                    className="bg-primary/95 text-primary-foreground hover:bg-primary"
                  >
                    Add to Day Sheet
                  </Button>
                </div>

                <div className="mt-5 grid gap-4 md:grid-cols-[1fr_auto_1fr] md:items-center">
                  <div className="space-y-2 text-left">
                    <p className="text-xs uppercase tracking-[0.18em] text-emerald-100/60">Player A</p>
                    <p className="font-display text-3xl font-extrabold uppercase tracking-[0.04em] text-white">
                      {playerA.playerName}
                    </p>
                    <div className="inline-flex rounded-full bg-sky-400/20 px-3 py-1 text-xs font-semibold tracking-wider text-sky-100">
                      {playerA.tour}
                    </div>
                    <p className="text-sm text-emerald-100/85">
                      {getSurfaceLabel(surface)} Elo: {formatElo(matchup.ratingA.value)}
                    </p>
                  </div>

                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-emerald-300/40 bg-emerald-900/25">
                    <TrendingUp className="h-8 w-8 text-primary" />
                  </div>

                  <div className="space-y-2 text-right">
                    <p className="text-xs uppercase tracking-[0.18em] text-emerald-100/60">Player B</p>
                    <p className="font-display text-3xl font-extrabold uppercase tracking-[0.04em] text-white">
                      {playerB.playerName}
                    </p>
                    <div className="inline-flex rounded-full bg-pink-400/20 px-3 py-1 text-xs font-semibold tracking-wider text-pink-100">
                      {playerB.tour}
                    </div>
                    <p className="text-sm text-emerald-100/85">
                      {getSurfaceLabel(surface)} Elo: {formatElo(matchup.ratingB.value)}
                    </p>
                  </div>
                </div>

                <div className="mt-6">
                  <div className="mb-2 flex items-center justify-between text-sm font-semibold text-emerald-100/85">
                    <span>{toPercent(probabilityA)} {playerA.playerName}</span>
                    <span>{toPercent(probabilityB)} {playerB.playerName}</span>
                  </div>
                  <div className="h-5 overflow-hidden rounded-full border border-emerald-300/30 bg-black/30">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-primary via-lime-300 to-accent transition-all duration-700"
                      style={{ width: `${Math.max(1, Math.min(99, probabilityA * 100))}%` }}
                    />
                  </div>
                </div>

                {matchup.ratingA.fallback || matchup.ratingB.fallback ? (
                  <p className="mt-4 rounded-xl border border-amber-300/40 bg-amber-300/10 px-3 py-2 text-xs text-amber-100">
                    One or both players are missing a {surface} Elo value, so overall Elo fallback was used.
                  </p>
                ) : null}

                <div className="mt-6 grid gap-3 md:grid-cols-2">
                  {[
                    { label: playerA.playerName, probability: probabilityA },
                    { label: playerB.playerName, probability: probabilityB },
                  ].map((entry) => (
                    <div key={entry.label} className="rounded-xl border border-emerald-300/25 bg-emerald-900/15 p-4">
                      <p className="font-display text-xl font-bold uppercase tracking-wide text-white">{entry.label}</p>
                      <div className="mt-3 grid grid-cols-3 gap-2 text-xs md:text-sm">
                        <div className="rounded-lg bg-black/30 px-2 py-2">
                          <p className="text-emerald-100/60">American</p>
                          <p className="font-semibold text-emerald-50">{toAmericanOdds(entry.probability)}</p>
                        </div>
                        <div className="rounded-lg bg-black/30 px-2 py-2">
                          <p className="text-emerald-100/60">Decimal</p>
                          <p className="font-semibold text-emerald-50">{toDecimalOdds(entry.probability)}</p>
                        </div>
                        <div className="rounded-lg bg-black/30 px-2 py-2">
                          <p className="text-emerald-100/60">Fractional</p>
                          <p className="font-semibold text-emerald-50">{toFractionalOdds(entry.probability)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="mt-6 rounded-2xl border border-red-300/40 bg-red-500/10 p-5 text-sm text-red-100">
                Selected players do not have enough Elo data for this comparison.
              </div>
            )}

            <div className="mt-7 rounded-2xl border border-emerald-300/35 bg-gradient-to-b from-emerald-950/30 to-black/40 p-4 md:p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="inline-flex items-center gap-2 rounded-full border border-primary/35 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100/80">
                    <CalendarDays className="h-3.5 w-3.5" />
                    Day Sheet
                  </p>
                  <p className="mt-2 text-sm text-emerald-100/70">
                    {daySheet.length} {daySheet.length === 1 ? "match" : "matches"} tracked today
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    onClick={downloadDaySheetAsImage}
                    disabled={!daySheet.length || isDownloadingDaySheet}
                    className="bg-primary/95 text-primary-foreground hover:bg-primary disabled:opacity-55"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    {isDownloadingDaySheet ? "Preparing Image" : "Download as Image"}
                  </Button>
                  <Button
                    onClick={clearDaySheet}
                    disabled={!daySheet.length}
                    variant="outline"
                    className="border-red-300/45 bg-red-500/10 text-red-100 hover:bg-red-500/20 disabled:opacity-55"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Clear All
                  </Button>
                </div>
              </div>

              <div
                ref={daySheetCaptureRef}
                className="rounded-2xl border border-emerald-300/25 bg-[#081810] p-4 shadow-[0_20px_70px_-45px_rgba(46,227,145,0.7)] sm:p-6"
              >
                <div className="mb-5 flex flex-wrap items-center justify-between gap-4 border-b border-emerald-300/25 pb-4">
                  <TennisProSheetMark />
                  <div className="rounded-xl border border-emerald-300/30 bg-emerald-900/20 px-3 py-2 text-right">
                    <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-emerald-100/65">Generated</p>
                    <p className="mt-1 text-sm font-semibold text-emerald-50">
                      {new Date().toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}
                    </p>
                  </div>
                </div>

                {daySheet.length ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-[1080px] w-full border-collapse text-sm">
                      <thead>
                        <tr className="border-b border-emerald-300/30 text-left text-[11px] uppercase tracking-[0.16em] text-emerald-100/70">
                          <th className="px-3 py-2">Match #</th>
                          <th className="px-3 py-2">Player 1</th>
                          <th className="px-3 py-2">Player 2</th>
                          <th className="px-3 py-2">Surface</th>
                          <th className="px-3 py-2">P1 Win%</th>
                          <th className="px-3 py-2">P2 Win%</th>
                          <th className="px-3 py-2">P1 Odds (Am/Dec)</th>
                          <th className="px-3 py-2">P2 Odds (Am/Dec)</th>
                          <th className="px-3 py-2">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {daySheet.map((entry, index) => (
                          <tr key={entry.id} className="border-b border-emerald-300/20 text-emerald-50/95 odd:bg-black/15 even:bg-emerald-900/10">
                            <td className="px-3 py-3 font-semibold">{index + 1}</td>
                            <td className="px-3 py-3">
                              <p className="font-semibold">{entry.player1}</p>
                              <p className="text-xs text-emerald-100/60">Added {formatDaySheetDate(entry.timestamp)}</p>
                            </td>
                            <td className="px-3 py-3 font-semibold">{entry.player2}</td>
                            <td className="px-3 py-3">{getSurfaceLabel(entry.surface)}</td>
                            <td className="px-3 py-3">{toPercent(entry.player1Prob)}</td>
                            <td className="px-3 py-3">{toPercent(entry.player2Prob)}</td>
                            <td className="px-3 py-3">{entry.player1AmericanOdds} / {entry.player1DecimalOdds}</td>
                            <td className="px-3 py-3">{entry.player2AmericanOdds} / {entry.player2DecimalOdds}</td>
                            <td className="px-3 py-3">
                              <button
                                onClick={() => removeFromDaySheet(entry.id)}
                                className="rounded-md border border-red-300/45 px-2 py-1 text-xs font-semibold uppercase tracking-[0.12em] text-red-100 transition hover:bg-red-500/20"
                              >
                                Remove
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="rounded-xl border border-dashed border-emerald-300/35 bg-emerald-950/20 px-4 py-8 text-center text-sm text-emerald-100/75">
                    Add matchups from above to build your day sheet before exporting.
                  </div>
                )}
              </div>
            </div>
          </section>
        ) : null}
      </section>
    </main>
  );
}
