import { NextResponse } from "next/server";
import { fetchRatingsSnapshot } from "@/lib/ratings";

export async function GET() {
  try {
    const payload = await fetchRatingsSnapshot();

    return NextResponse.json(payload, {
      headers: {
        "cache-control": "no-store",
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown scraping error";
    console.error("[scrape-ratings] Failed to load ratings", error);

    return NextResponse.json(
      {
        error: message,
        hint: "Retry in a moment. If Tennis Abstract is blocking traffic, fallback mode should recover automatically.",
      },
      {
        status: 500,
        headers: {
          "cache-control": "no-store",
        },
      },
    );
  }
}
